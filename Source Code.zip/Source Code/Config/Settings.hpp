#pragma once

const float SCREEN_WIDTH = 600.0f;
const float SCREEN_HEIGHT = 600.0f;